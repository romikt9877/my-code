import mysql.connector
from sklearn import tree, preprocessing


conn = mysql.connector.connect(user='root', password='', host='127.0.0.1', database='maktabkhooneh')
cursor = conn.cursor(dictionary=True)

cursor.execute("SELECT * FROM `cars`")
result = cursor.fetchall()

lb = preprocessing.LabelEncoder()

print('Learning...')

x = []
y = []

make_models = []
trims = []
for row in result:
    make_models.append(row["make_model"])
    trims.append(row["trim"])

lb_make_models = lb.fit_transform(make_models)
lb_trims = lb.fit_transform(trims)

i = 0
for row in result:
    x.append([
        lb_make_models[i], row["year"], lb_trims[i], row["mileage"]
    ])
    y.append(row["price"])
    i += 1



clf = tree.DecisionTreeClassifier()
clf = clf.fit(x, y)
print('Done!')
print('')
print('Enter the required information to estimate the price')

make_model = input('make model (like "Chevrolet Volt"): ')
make_model = lb_make_models[make_models.index(make_model)]

year = input('year (like "2019"): ')

trim = input('trim (like "LT"): ')
trim = lb_trims[trims.index(trim)]

mileage = input('mileage (like "28800"): ')

data = [
    [
        make_model,
        year,
        trim,
        mileage
    ]
]

print("Estimated price:", clf.predict(data)[0])
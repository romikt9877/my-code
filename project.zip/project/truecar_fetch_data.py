from bs4 import BeautifulSoup
import requests
import mysql.connector
import re


conn = mysql.connector.connect(user='root', password='', host='127.0.0.1', database='maktabkhooneh')
cursor = conn.cursor()


r = requests.get('https://www.truecar.com/used-cars-for-sale/listings/')

soup = BeautifulSoup(r.text, 'html.parser')

all_ads = soup.find_all('div', {'class': 'vehicle-card'})
count_in_page = 0
for item in all_ads:
    id = item['data-test-item']
    make_model = item.find('span', {'class': 'vehicle-header-make-model'}).text
    trim = item.find('div', {'data-test': 'vehicleCardTrim'}).text
    year = item.find('span', {'class': 'vehicle-card-year'}).text
    mileage = item.find('div', {'data-test': 'vehicleMileage'}).text
    mileage = re.search(r'\d+', mileage.replace(',', '')).group(0)

    price = item.find('div', {'data-test': 'vehicleCardPricingBlockPrice'}).text.replace(',', '').replace('$', '')

    print(id, make_model, trim, mileage, price)
    
    cursor.execute("SELECT * FROM `cars` WHERE `truecar_id` = '"+id+"'")
    result = cursor.fetchall()
    if len(result) == 0:
        cursor.execute('INSERT INTO `cars` (`truecar_id`, `make_model`, `trim`, `year`, `price`, `mileage`) VALUES ("'+id+'", "'+make_model+'", "'+trim+'", "'+year+'", "'+mileage+'", "'+price+'")')
        conn.commit()



conn.close()
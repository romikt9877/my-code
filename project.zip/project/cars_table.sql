-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 21, 2021 at 08:04 AM
-- Server version: 5.7.24
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `maktabkhooneh`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `truecar_id` varchar(255) COLLATE utf32_persian_ci NOT NULL,
  `make_model` varchar(255) COLLATE utf32_persian_ci NOT NULL,
  `year` int(11) NOT NULL,
  `trim` varchar(255) COLLATE utf32_persian_ci NOT NULL,
  `price` int(11) NOT NULL,
  `mileage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_persian_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`truecar_id`, `make_model`, `year`, `trim`, `price`, `mileage`) VALUES
('1FMCU0G69LUB19072', 'Ford Escape', 2020, 'SE FWD', 17814, 21495),
('1FT7W2B63KEF41544', 'Ford Super Duty F-250', 2019, 'Lariat 4WD Crew Cab 6.75\' Box', 50741, 55999),
('1FTEW1CF3HFA18978', 'Ford F-150', 2017, 'Lariat SuperCrew 5.5\' Box RWD', 218568, 20897),
('1FTEW1CP3JKC21469', 'Ford F-150', 2018, 'XL SuperCrew 5.5\' Box 2WD', 178500, 20488),
('1FTEW1E50KKC40400', 'Ford F-150', 2019, 'XLT SuperCrew 5.5\' Box 4WD', 45891, 30500),
('1FTEW1EB0JFC49255', 'Ford F-150', 2018, 'XLT SuperCrew 5.5\' Box 4WD', 49495, 32997),
('1FTEW1EB2JFA08345', 'Ford F-150', 2018, 'XLT SuperCrew 5.5\' Box 4WD', 47922, 34142),
('1FTEW1EB3JFD94709', 'Ford F-150', 2018, 'XL SuperCrew 5.5\' Box 4WD', 52338, 31500),
('1FTEW1EB3JKE97104', 'Ford F-150', 2018, 'XLT SuperCrew 5.5\' Box 4WD', 110104, 28495),
('1FTEW1EG6JKC03139', 'Ford F-150', 2018, 'Lariat SuperCrew 5.5\' Box 4WD', 120122, 28800),
('1FTEW1EP0KKE42459', 'Ford F-150', 2019, 'XLT SuperCrew 5.5\' Box 4WD', 12615, 39555),
('1FTEW1EP2JFD20466', 'Ford F-150', 2018, 'XLT SuperCrew 5.5\' Box 4WD', 28833, 37782),
('1FTFW1EF9EKE86119', 'Ford F-150', 2014, 'XL SuperCrew 5.5\' Box 4WD', 96957, 20999),
('1G1RC6S5XJU142238', 'Chevrolet Volt', 2018, 'LT', 58371, 18957),
('1HGCV1F38KA081723', 'Honda Accord', 2019, 'Sport 1.5T CVT', 26955, 24999),
('1N4AL3AP4FN386643', 'Nissan Altima', 2015, '2.5 S', 92366, 10995),
('2C3CDZBT8JH305633', 'Dodge Challenger', 2018, 'R/T Plus Shaker RWD', 21863, 37699),
('2G1105S36K9110898', 'Chevrolet Impala', 2019, 'Premier with 2LZ', 100439, 18450),
('3C4PDCAB4JT171830', 'Dodge Journey', 2018, 'SE FWD', 137454, 10995),
('3FA6P0H73GR196166', 'Ford Fusion', 2016, 'SE FWD', 59575, 14500),
('3GCUYDED0KG261298', 'Chevrolet Silverado 1500', 2019, 'LT Crew Cab Short Box 4WD', 36310, 42995),
('3GTU2NEC6JG141664', 'GMC Sierra 1500', 2018, 'SLT Crew Cab Short Box 4WD', 145702, 31500),
('3N1AB7AP9JY224865', 'Nissan Sentra', 2018, 'SV CVT', 108158, 10995),
('3N1AB7APXKL604411', 'Nissan Sentra', 2019, 'SV CVT', 40000, 12850),
('3TMCZ5AN5KM204481', 'Toyota Tacoma', 2019, 'TRD Pro Double Cab 5\' Bed V6 4WD Automatic', 46209, 40500),
('3VWC57BU8KM149860', 'Volkswagen Jetta', 2019, 'S Automatic', 33000, 15995),
('3VWC57BUXKM082355', 'Volkswagen Jetta', 2019, 'S Automatic', 27868, 21995),
('55SWF4JB2JU251278', 'Mercedes-Benz C-Class', 2018, 'C 300 Sedan RWD', 35536, 29828),
('55SWF4JB4JU279826', 'Mercedes-Benz C-Class', 2018, 'C 300 Sedan RWD', 21043, 33908),
('5NPD84LF7JH327792', 'Hyundai Elantra', 2018, 'SEL 2.0L Sedan Automatic', 74967, 12994),
('5NPDH4AE2GH680069', 'Hyundai Elantra', 2016, 'SE Sedan Automatic', 140437, 7900),
('JF2SKAGC0KH591929', 'Subaru Forester', 2019, '2.5i Premium', 18122, 23900),
('JTNB11HK0J3019337', 'Toyota Camry', 2018, 'SE I4 Automatic', 34219, 17000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD UNIQUE KEY `truecar_id` (`truecar_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
